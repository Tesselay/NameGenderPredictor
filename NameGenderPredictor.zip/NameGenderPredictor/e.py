import pandas as pd
from sklearn.preprocessing import OneHotEncoder

enc = OneHotEncoder(handle_unknown='ignore')
X = ['am', 'am', 'es', 'an', 'in', 'on', 'ah', 'er', 'ob', 'as', 'el', 'er', 'an', 'el', 'ew', 'en']
x = ['m', 'm', 's', 'n', 'n', 'n', 'h', 'r', 'b', 's', 'l', 'r', 'n', 'l', 'w', 'n']
XX = ['iam', 'iam', 'mes', 'gan', 'min', 'son', 'jah', 'ver', 'cob', 'cas', 'ael', 'der', 'han', 'iel', 'hew', 'den']
test = pd.DataFrame(x, columns=['1l'])
yeet = pd.DataFrame(X, columns=['2l'])
allu = pd.DataFrame(XX, columns=['3l'])

ou = pd.concat([test, yeet], axis=1, sort=False, ignore_index=False, join='outer')
ou = ou.dropna()

enc.fit(ou)
print(enc.transform([['am']]).toarray())